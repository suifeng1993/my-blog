
## 站点架构约定（风与墨博客）
- 目录层级：`my-blog/` 为外层容器，内含平级两项 —— `my-blog-0/`（纯净静态部署包）+ `.workbuddy/`（工具目录）；上传 Cloudflare Pages 时拖拽 `my-blog-0/` 即可，.workbuddy 天然在部署包之外
- 主题系统：CSS 变量令牌（:root 浅色 + `[data-theme="dark"|"light"]` 及 `@media prefers-color-scheme`）；
  切换逻辑在每页 `<head>` 内联脚本（无闪烁 + 三态持久化），切换按钮由 JS 注入 `.nav`
- 样式单来源：`css/style.css`（首页第12节也已并入）；`_blog-templates/` 在站点根外，不进部署包
- 部署：Cloudflare Pages 直接上传 `my-blog-0/` 根目录（纯静态，相对路径，无构建步骤），自定义域 www.suifeng1993.com
- 两篇老龄化报告为深蓝"报告专属色"自包含组件，明暗主题均保留深蓝
