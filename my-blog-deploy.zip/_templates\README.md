# 风与墨 · 文章模板使用指南

> 5 种模板，覆盖不同类型的内容。复制 → 改内容 → 发布。

---

## 模板速查表

| 模板文件 | 内容类型 | 适用场景 | 结构复杂度 | 用到的扩展元素 |
|---|---|---|---|---|
| `_template-essay.html` | 随笔感悟 | 日常感悟、生活片段、即兴思考 | ★☆☆ 轻量 | p / h2 / blockquote / hr |
| `_template-reading-notes.html` | 读书笔记 | 单本书的读后感、书评 | ★★☆ 中等 | note-box / excerpt-card / insight-box |
| `_template-deep-analysis.html` | 深度分析报告 | 数据报告、趋势分析、主题研究 | ★★★ 重量 | data-table / kpi-row / stage-timeline / info-grid / conclusion-box |
| `_template-comparison.html` | 主题对比 | 跨书 / 跨电影的横向比较 | ★★☆ 中等 | comparison-table / excerpt-card / insight-box / info-card |
| `_template-excerpts.html` | 摘抄手记 | 金句收集、碎片记录 | ★☆☆ 轻量 | excerpt-card / note-box / insight-box |

---

## 使用方法（3 步）

### 第 1 步：选模板 → 复制到栏目目录

把模板文件从 `_templates/` 复制到对应栏目文件夹，改名为 `日期-英文标题.html`：

```bash
# 例：在听风栏目写一篇读书笔记
cp _templates/_template-reading-notes.html posts/listening/2026-08-15-book-name.html

# 例：在晓风栏目写一篇随笔
cp _templates/_template-essay.html posts/dawn/2026-08-15-reflection.html
```

### 第 2 步：改 5 个地方

打开新文件，只改这些（其余保持不动）：

1. **`<title>` 和 `<meta description>`** — 换成你的文章标题
2. **`<header>` 区块** — 标题、日期、字数、栏目标签
3. **`<article>` 正文** — 替换占位文字为你自己的内容
4. **栏目路径** — 如果跨栏目使用，修改 breadcrumb 和导航里的 `index.html` 链接路径
5. **上下篇导航**（可选）— 把 `nav-placeholder` 换成实际链接

### 第 3 步：更新索引页

在对应栏目的 `index.html` 里加一条文章链接，在首页 `index.html` 的"近期落墨"里也加一条。

---

## 各模板详细说明

### 1. 随笔感悟型 `_template-essay.html`

**什么时候用**：想写一段不太长的感悟，没有数据表格、没有复杂结构，就是"看到一件事 → 想到一些东西 → 记下来"。

**结构**：场景引入 → 第一个思考节点 → 更深一层 → 分隔线 → 收束

**特点**：
- 只用最基础的 HTML 元素（段落、标题、引用、列表）
- 不需要任何扩展 CSS class
- 适合 800-2000 字的文章

**正文可用元素**：
```html
<p>段落</p>
<h2>小标题</h2>
<h3>更小的标题</h3>
<blockquote><p>引用</p><p>—— 出处</p></blockquote>
<ul><li>无序列表</li></ul>
<ol><li>有序列表</li></ol>
<hr />
```

---

### 2. 读书笔记型 `_template-reading-notes.html`

**什么时候用**：读完一本书，想记录摘抄 + 自己的批注 + 整体感受。

**结构**：书籍信息卡 → 阅读缘起 → 摘抄批注（多条）→ 整体评述 → 一句话收获

**关键元素**：

```html
<!-- 书籍信息卡 -->
<div class="note-box">
  <strong>书名：</strong>《书名》<br>
  <strong>作者：</strong>作者名<br>
  ...
</div>

<!-- 摘抄 + 批注卡片 -->
<div class="excerpt-card">
  <div class="excerpt-text">
    <p>原文摘抄</p>
    <p>—— 第 X 页</p>
  </div>
  <div class="excerpt-note">
    批注写在这里
  </div>
</div>

<!-- 洞察框 -->
<div class="insight-box">
  <h4>标题</h4>
  <p>内容</p>
</div>
```

---

### 3. 深度分析报告型 `_template-deep-analysis.html`

**什么时候用**：想写一篇有数据、有表格、有时间线、有结论的重量级分析文章。参考范例：`posts/listening/2026-08-13-aging-china.html`。

**结构**：方法论声明 → 核心发现 → 多章节分析（含 KPI/表格/洞察框）→ 阶段时间线 → 风险路径 → 国际镜鉴 → 判断框架 → 数据源 → 结语

**关键元素**：

```html
<!-- 带序号章节标题 -->
<div class="sec-title"><span class="sec-num">一</span>章节标题</div>
<p class="sec-desc">章节描述</p>

<!-- KPI 卡片行 -->
<div class="kpi-row">
  <div class="kpi-card">
    <div class="kpi-num">数字</div>
    <div class="kpi-label">标签</div>
  </div>
</div>

<!-- 数据表格 -->
<table class="data-table">
  <thead><tr><th>列名</th></tr></thead>
  <tbody>
    <tr class="row-highlight"><td>高亮行</td></tr>
    <tr class="row-warn"><td>警告行</td></tr>
  </tbody>
</table>
<p class="table-source">数据来源说明</p>

<!-- 阶段时间线 -->
<div class="stage-timeline">
  <div class="stage-item active">
    <div class="stage-label">阶段名</div>
    <div class="stage-body">内容</div>
  </div>
</div>

<!-- 信息卡片网格 -->
<div class="info-grid">
  <div class="info-card"><h4>标题</h4><p>内容</p></div>
  <div class="info-card warn"><h4>警告</h4><p>内容</p></div>
</div>

<!-- 洞察框变体 -->
<div class="insight-box">绿灰（默认）</div>
<div class="insight-box warn">红色</div>
<div class="insight-box dark">深色</div>

<!-- 结论框 -->
<div class="conclusion-box">
  <h3>结语标题</h3>
  <p>内容</p>
</div>

<!-- 分隔符 -->
<div class="divider">◇ ◇ ◇</div>
```

---

### 4. 主题对比型 `_template-comparison.html`

**什么时候用**：读了几本同主题的书（或看了几部同题材的电影），想比较它们的不同视角。

**结构**：主题导入 → 逐个作品分析 → 横向对比表 → 综合判断

**关键元素**：

```html
<!-- 对比表格 -->
<table class="comparison-table">
  <thead>
    <tr><th>维度</th><th>作品 A</th><th>作品 B</th></tr>
  </thead>
  <tbody>
    <tr><td class="dim-name">维度名</td><td>内容</td><td>内容</td></tr>
  </tbody>
</table>
```

---

### 5. 摘抄手记型 `_template-excerpts.html`

**什么时候用**：读书时摘了一堆金句，想整理成一篇合集。不需要长篇分析，摘抄 + 短批注即可。

**结构**：导入 → 多条摘抄批注 → 整理回顾

**特点**：
- 每条摘抄用 `excerpt-card` 卡片
- 批注可以很短（一两句话）
- 5-10 条比较合适
- 末尾用 `insight-box` 做一句串联

---

## 跨栏目使用

模板默认放在 `posts/listening/`（听风）目录下。如果要在其他栏目使用，修改以下路径：

```html
<!-- 栏目标签 -->
<div class="cat-tag">听 风 · ...</div>  →  观 风 · ... / 晓 风 · ... / 吟 风 · ... / 回 风 · ...

<!-- 面包屑 -->
<a href="index.html">听风</a>  →  观风 / 晓风 / 吟风 / 回风

<!-- 返回导航 -->
<a href="index.html">← 返回听风</a>  →  ← 返回观风 / ← 返回晓风 / ...
```

导航和页脚的路径不需要改——它们用的是 `../../index.html` 和 `../echo/index.html`，对所有栏目都通用。

---

## 样式说明

所有扩展元素的样式都在 `css/style.css` 的第 11 节"扩展文章元素"中定义，使用站点的 CSS 变量（绿灰色调），自动适配暗色模式。

如果需要添加新的元素样式，在 `style.css` 的第 11 节末尾添加，不要在单个文章文件里写 scoped 样式——保持样式集中管理。

---

## 栏目与 cat-tag 对照

| 栏目 | 目录 | cat-tag 写法 |
|---|---|---|
| 听风 | `posts/listening/` | `听 风 · 阅 读 笔 记` |
| 观风 | `posts/watching/` | `观 风 · 影 视 评 论` |
| 晓风 | `posts/dawn/` | `晓 风 · 思 考 感 悟` |
| 吟风 | `posts/reciting/` | `吟 风 · 诗 歌 散 文` |
| 回风 | `posts/echo/` | `回 风 · 来 信 回 复` |
